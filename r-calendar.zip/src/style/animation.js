export const lipop = {
    init:{scale:1,x:1000, opacity:0},
    play:{scale:1,x:0, opacity:1,
    transition:{duration:2, ease:'circOut'},
    }
}
export default lipop;